/*
const express = require("express");
const app = express();

const product = require('./models/products');
const client = require('./models/clients');

const router = express.Router();



const { default: mongoose } = require("mongoose");
// const { Router } = require("express");
mongoose.connect('mongodb://127.0.0.1:27017/pro', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log('connection open!!');
    })
    .catch(err => {
        console.log('connection erorr!!');
        console.log(err);
    })*/

// קובץ pro.js
// כאן יש כמה שורות קוד...

// הוספת הפונקציה addToCart וקוד ההצגה של העגלה עם הפריטים
// pro.js

// פונקציה להוספת פריט לסל הקניות
// הוספת הפונקציה addToCart וקוד ההצגה של העגלה עם הפריטים
// pro.js


function addToCart(name, price) {
    const newItem = { name, price, quantity: 1 };

    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];

    const existingItemIndex = cartItems.findIndex(item => item.name === name);

    if (existingItemIndex !== -1) {
        cartItems[existingItemIndex].quantity += 1;
    } else {
        cartItems.push(newItem);
    }

    localStorage.setItem('cartItems', JSON.stringify(cartItems));
    alert(`${name} added to cart!`);
    displayCart();
}

function calculateTotal() {
    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    let total = 0;

    cartItems.forEach(item => {
        total += (item.price || 0) * (item.quantity || 1);
    });

    return total;
}

function displayCart() {
    const shoppingCart = document.getElementById('shopping-cart');
    const totalElement = document.getElementById('total');
    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];

    shoppingCart.innerHTML = '';
    cartItems.forEach(item => {
        const cartItem = document.createElement('div');
        cartItem.innerHTML = `
            <p>${item.name} - ₪${item.price}  - כמות: ${item.quantity}</p>
            <button onclick="removeFromCart('${item.name}')">הסרה</button>
        `;
        shoppingCart.appendChild(cartItem);
    });

    const total = calculateTotal();
    totalElement.innerHTML = `סך הכל:  ₪${total}`;
}
function checkout() {
    alert("Thank you for your purchase!");
    localStorage.removeItem('cartItems');
    displayCart();
}


function removeFromCart(name) {
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];

    const existingItemIndex = cartItems.findIndex(item => item.name === name);

    if (existingItemIndex !== -1) {
        if (cartItems[existingItemIndex].quantity > 1) {
            cartItems[existingItemIndex].quantity -= 1;
        } else {
            cartItems = cartItems.filter(item => item.name !== name);
        }

        localStorage.setItem('cartItems', JSON.stringify(cartItems));
        displayCart();
    }
}

window.onload = displayCart;


function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (username === 'shilats' && password === '1234567') {
        window.location.href = 'pro7.html';
    } else {
        alert('Invalid username or password');
    }
}



function addNewItem() {
    const name = document.getElementById('newItemName').value;
    const price = document.getElementById('newItemPrice').value;
    const category = document.getElementById('newItemCategory').value;


    fetch('/addItem', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, price, category }),
    })
        .then(response => response.json())
        .then(data => {
            alert('Item added successfully!');
        })
        .catch(error => {
            alert('Error adding item');
        });
}


