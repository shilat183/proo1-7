const express = require("express");
const app = express();

const product = require('./models/products');
const client = require('./models/clients');

const router = express.Router();

const mongoose = require("mongoose");
mongoose.connect('mongodb://127.0.0.1:27017/pro', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log('connection open!!');
    })
    .catch(err => {
        console.log('connection error!!');
        console.log(err);
    })



