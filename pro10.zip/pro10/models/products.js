const mongoose = require('mongoose');
const productSchema = new mongoose.Schema({
    name: {
        type: String,
        require: true
    },

    price: {
        type: Number,
        require: true,
        min: 0

    },
    category: {
        type: String,
        require: true
    },


})
const Product = mongoose.model('Product', productSchema);

Product.insertMany([
    { name: "שרשרת מגן דוד", price: 600, category: 'necklace' },
    { name: "שרשרת טניס", price: 520, category: 'necklace', },
    { name: "שרשרת לב ", price: 260, category: 'necklace', },
    { name: "שרשרת מלאך'", price: 640, category: 'necklace', },
    { name: " שרשרת קונכייה", price: 360, category: 'necklace' },
    { name: " שרשרת פרח לורן", price: 400, category: 'necklace' },
    { name: " שרשרת משובצת קלאסית", price: 680, category: 'necklace' },
    { name: " שרשרת עיגול", price: 450, category: 'necklace' },
    { name: " טבעת כסך קלאסית משובצת", price: 520, category: 'Ring' },
    { name: " טבעת כוכב הצפון", price: 350, category: 'Ring' },
    { name: "טבעת חץ ", price: 400, category: 'Ring' },
    { name: " טבעת יהלום קטן", price: 620, category: 'Ring' },
    { name: "טבעת בל ", price: 250, category: 'Ring' },
    { name: " טבעת סנפיר", price: 550, category: 'Ring' },
    { name: "טבעת פרפר ", price: 520, category: 'Ring' },
    { name: " טבעת סנייק", price: 230, category: 'Ring' },
    { name: " טבעת עיגול ", price: 300, category: 'Ring' }
]).then(data => {
    console.log('it works!!');
})
    .catch(err => {

        console.log(err);
    })

